package com.sk;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class test {
 private static String collect3;

public static void main(String[] args) {
	// ArrayList<Integer>list= new ArrayList<Integer>();
	 List<Integer> list = List.of(101,102,103,104,105);
	 List<String> list1 = List.of("ramesha","suresha","rada","ram","raj","rampa");
	 List<Integer> list2 = List.of(101,102,103,104,105,102,103,104,105);
	 //char targetChar='s';
	String str="shushanth";
	//IntStream IntegerStream= IntStream.of(97,96,95,94,92);
	
	 List<Integer> list3 = List.of(10,12,13,14,105,106);
	
	Integer [][] arrays = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
	
	//Java 8 program to find the Minimum and maximum number of a Stream?

	 
		System.out.println("----------1-----------------------");
		 
	  Optional<Integer> min = list.stream().min((a,b)->a.compareTo(b));
	 System.out.println(min);
			 
	 
	  Optional<Integer> max = list.stream().max((a,b)->a.compareTo(b));
	  System.out.println(max);
	  
	  
	System.out.println("-------------2--------------------");
	  
	  
	//Java 8 program to Count Strings whose length is greater than 3 in List?

	  long count  = list1.stream().filter(m->m.length()>3).count();
	  System.out.println(count);
	  
	  System.out.println("--------------3-------------------");
	  
	  
	  //Java 8 program to multiply 3 to all element in list and print the list?
	  List<Integer> collect = list.stream().map(m->m*3).collect(Collectors.toList());
      System.out.println(collect);
      
      System.out.println("------------4---------------------");
      
      //Java 8 program to remove the duplicate elements from the list?
      List<Integer> collect2 = list2.stream().distinct().collect(Collectors.toList());
      System.out.println(collect2);

      System.out.println("-----------5----------------------");
      
      //Find the last element of a Stream in Java
       Optional<Integer> reduce = list.stream().reduce((a,b)->b);
       System.out.println(reduce);
       
       System.out.println("---------------6------------------");
      // Count occurrence of a given character in a string using Stream API in Java
      long count2 = str.chars().filter(ch -> ch == 's').count();
       System.out.println(count2);
       
       System.out.println("--------------7-------------------");

//     Flatten a Stream of Arrays in Java using forEach loop
//
//	    Input: arr[][] = {{ 1, 2 }, { 3, 4, 5, 6 }, { 7, 8, 9 }}


       
       List<Integer> collect4 = Arrays.stream(arrays).flatMap(x->Arrays.stream(x)).collect(Collectors.toList());
       //List<Integer> collect4 = Arrays.stream(arr).flatMap(t -> Arrays.stream(t)).collect(Collectors.toList());
       

       System.out.println(collect4);
       
       
       System.out.println("--------------8-------------------");
       //Program to convert IntStream to String in Java
         IntStream of = IntStream.of(97, 98);
//       String string = of.collect(StringBuilder::new,
//        StringBuilder::appendCodePoint,
//       StringBuilder::append)
//       .toString();
//       
         String collect5 = of.mapToObj(c-> (char)c).map(c ->c.toString()).collect(Collectors.joining());
       
       
       System.out.println(collect5);
      
       System.out.println("-------------9--------------------");
      // Write a Java 8 program to square the list of numbers and then filter out the numbers greater than 100 and 
       //then find the average of the remaining numbers?

       double double1 = list3.stream().map( y -> y* 2).filter(y -> y<100).mapToInt(y ->y).average().getAsDouble();
      System.out.println(double1);
      
      
      
      
      
}
}

